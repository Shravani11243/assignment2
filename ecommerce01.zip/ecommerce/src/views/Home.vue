<template>
 <div class="home">
  <Main />
 </div>
</template>
<script>
import Main from "./Main.vue";

export default {
 name:'home',
 components: {
  Main
 }

}
</script>
<style>
 
</style>