<template lang="">
 <div>
  Product Procesing
 </div>
</template>
<script>
export default {
 
}
</script>
<style lang="">
 
</style>