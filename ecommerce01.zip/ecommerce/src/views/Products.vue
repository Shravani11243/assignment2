<template lang="">
 <div>
  All products Page
 </div>
</template>
<script>
export default {
 
}
</script>
<style lang="">
 
</style>