<template>
 <div id="footer">
  Copyright @2021
 </div>
</template>
<script>
export default {
 
}
</script>
<style>
 #footer {
  text-align: center;
 }
</style>