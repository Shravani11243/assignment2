﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Rectangle;

namespace RectangleTest
{

    

    [TestFixture]
    public class RectangleTest
    {

        [Test]

        public void GetWidth_Testing()
        {
           RectangleClass rect = new RectangleClass();
            int width = rect.GetWidth();
            Assert.AreEqual(1, width);

        }

        [Test]
        public void GetLength_Testing()
        {
            RectangleClass rect = new RectangleClass();
            int length = rect.GetLength();
            Assert.AreEqual(1, length);
        }

        [Test]
        public void SetWidth_Testing()
        {
            RectangleClass rect = new RectangleClass();
            int setwidth = rect.SetWidth(15);
            Assert.AreEqual(15,setwidth);
        }
        [Test]
        public void SetLength_Testing()
        {
            RectangleClass rect = new RectangleClass();
            int setlength = rect.SetLength(20);
            Assert.AreEqual(20, setlength);
        }
        [Test]
        public void GetPerimeter_Testing()
        {
            RectangleClass rect = new RectangleClass( 5,10);
            int perimeter = rect.GetPerimeter();
            Assert.AreEqual(30, perimeter);
        }
        [Test]
        public void GetArea()
        {
            RectangleClass rect = new RectangleClass(10,8);
            int area = rect.GetArea();
            Assert.AreEqual(80, area);
        }
    }
    }

