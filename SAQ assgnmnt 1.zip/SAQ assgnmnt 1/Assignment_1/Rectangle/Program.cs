﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Rectangle
{
    class Program
    {

        static void Main(string[] args)

        {
            Console.WriteLine("Figure 1 Example Assignmengt 01 Solution");
            int givenLength, givenWidth;
            int len;
            int Wid;
            int Menu;

            Console.Write("Please Enter the length:");
            givenLength = Convert.ToInt32(Console.ReadLine());
            Console.Write("Please Enter the width:");
            givenWidth = Convert.ToInt32(Console.ReadLine());

            RectangleClass rect = new RectangleClass(givenLength, givenWidth);

            
                if (givenLength > 0 && givenWidth > 0)
                {
                    do
                    {
                 
                        Console.WriteLine("Please select any option from the below Menu");
                        Console.WriteLine("1. Get Rectangle Length");
                        Console.WriteLine("2. Change Rectangle Length");
                        Console.WriteLine("3. Get Rectangle Width");
                        Console.WriteLine("4. Change Rectangle Width");
                        Console.WriteLine("5. Get Rectangle Perimeter");
                        Console.WriteLine("6. Get Rectangle Area");
                        Console.WriteLine("7.Exit");

                        Menu = Convert.ToInt32(Console.ReadLine());

                        if (Menu == 1)
                        {
                           Console.WriteLine("Length of Rectangle " + rect.GetLength());

                        }
                        else if (Menu == 2)
                        {
                            Console.Write("Please Enter the length:");
                            len = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Changed Length of Rectangle " + rect.SetLength(len));
                        }
                        else if (Menu == 3)
                        {

                            Console.WriteLine("Width of Rectangle " + rect.GetWidth());
                        }
                        else if (Menu == 4)
                        {
                            Console.Write("Please Enter the Width:");
                            Wid = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Changed Width of Rectangle " + rect.SetWidth(Wid));
                        }
                        else if (Menu == 5)
                        {

                            Console.WriteLine("Perimeter of Rectangle " + rect.GetPerimeter());
                        }
                        else if (Menu == 6)
                        {
                            Console.WriteLine("Area of Rectangle " + rect.GetArea());
                        }
                    } while (Menu != 7);
                }
                else
                {
                    Console.WriteLine("Please enter the correct values");
                }
           
        }
    }
}
    

